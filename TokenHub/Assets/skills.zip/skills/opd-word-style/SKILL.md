---
name: opd-word-style
description: >-
  Standard styling, formatting rules, and python-docx template for generating and formatting Russian
  academic laboratory and practical work reports (ОПД / Основы проектной деятельности, e.g. ПР №13,
  ПР №14, ПР №15, ПР №16) in DOCX format matching the exact reference style of "ПР №15 ОПД Костин Никита Вариант 2.docx".
  Applies 0.5 in (36pt) margins, Times New Roman 14pt body with 1.5 line spacing, justified alignment,
  centered 14pt bold title block, standard black font, full-bordered academic tables (#EAECEE header,
  10.5pt bold, #A0A0A0 borders, alternating white/light-gray rows), centered images with 12pt captions
  (Рисунок X. Название), and numbered sections (Раздел 1, 1.1).
  Use whenever asked to format or create an OPD practical/laboratory report in Word or when the user says
  "оформи word как опд 15", "стиль опд", "оформи ворд как в 15", "/opd-word", or similar.
---

# OPD Word Report Formatting Standard (Стиль отчетов ОПД)

Данный скилл регламентирует эталонные правила и готовый программный код для генерации отчетов по дисциплине **«Основы проектной деятельности» (ОПД)** и смежным инженерно-управленческим курсам. Форматирование в точности воспроизводит эталонный документ **`ПР №15 ОПД Костин Никита Вариант 2.docx`**.

---

## 1. Базовые типографические и геометрические параметры

| Параметр | Значение | Реализация в python-docx |
| :--- | :--- | :--- |
| **Формат страницы** | Letter / A4 Портретная | `s.page_width = Pt(612.0)`, `s.page_height = Pt(792.0)` |
| **Поля (все 4 стороны)** | **36.0 pt (0.5 дюйма / 1.27 см)** | `s.top_margin = Pt(36.0)`, `s.bottom_margin = Pt(36.0)`, `s.left_margin = Pt(36.0)`, `s.right_margin = Pt(36.0)` |
| **Основной шрифт** | **Times New Roman, 14.0 pt** | `run.font.name = 'Times New Roman'`, `run.font.size = Pt(14)` |
| **Межстрочный интервал** | **1.5 строки** | `p.paragraph_format.line_spacing = 1.5` |
| **Выравнивание текста** | **По ширине (Justified)** | `p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY` |
| **Отбивка после абзаца** | **2.0 – 3.0 pt** (до абзаца: 0 pt) | `p.paragraph_format.space_after = Pt(2.5)`, `space_before = Pt(0)` |
| **Цвет текста** | Стандартный черный (None/Auto) | Не задавать цветные стили, оставлять стандартный черный |

---

## 2. Структура вводного титульного блока

Титульный блок оформляется строго следующей последовательностью абзацев без пустых строк:

1. `ПРАКТИЧЕСКАЯ РАБОТА №X` — **По центру, 14 pt, Полужирный**, интервал 1.5, `sa=2.0 pt`.
2. `<Название темы>. Вариант X` — **По центру, 14 pt, Полужирный**, интервал 1.5, `sa=2.0 pt`.
3. `Тема: <Развернутое наименование темы>` — **По центру, 14 pt, Полужирный**, интервал 1.5, `sa=6.0 pt`.
4. `Выполнил: Студент: Костин Никита (Группа ИС-41)` — **По ширине, 14 pt**, префикс `Выполнил: Студент: ` полужирный, интервал 1.5, `sa=2.0 pt`.
5. `Роль на проекте: <Роль студента>` — **По ширине, 14 pt**, префикс `Роль на проекте: ` полужирный, интервал 1.5, `sa=4.0 pt`.
6. `Цели работы: <Развернутый текст целей>` — **По ширине, 14 pt**, префикс `Цели работы: ` полужирный, интервал 1.5, `sa=6.0 pt`.
7. `Исходные данные и легенда проекта (Вариант X)` — **По ширине, 14 pt, Полужирный**, интервал 1.5, `sa=3.0 pt`.

---

## 3. Заголовки разделов и подразделов

* **Заголовок раздела:**
  * Формат: `Раздел X. <Название раздела>`
  * Стиль: Times New Roman, **14.0 pt, Полужирный**, выравнивание **По ширине**, интервал 1.5, `sa=3.0 pt`, `sb=3.0 pt`.
* **Заголовок подраздела:**
  * Формат: `X.X. <Название подраздела>`
  * Стиль: Times New Roman, **14.0 pt, Полужирный**, выравнивание **По ширине**, интервал 1.5, `sa=2.0 pt`, `sb=2.0 pt`.

---

## 4. Оформление таблиц

Все таблицы в отчете форматируются по академическому стандарту:

1. **Границы:**
   * Все 6 видов границ (верхняя, нижняя, левая, правая, внутренние горизонтальные, внутренние вертикальные) активны.
   * Тип: `single` (одинарная линия), толщина: `sz="4"`, цвет: серый `#A0A0A0`.
2. **Шапка таблицы (Row 0):**
   * Заливка: светло-серая `#EAECEE`.
   * Шрифт: Times New Roman, **10.5 pt, Полужирный**.
   * Выравнивание: По центру (`WD_ALIGN_PARAGRAPH.CENTER`).
   * Внутренние поля ячеек: `top=100`, `bottom=100`, `left=120`, `right=120` dxa.
3. **Строки данных (Data Rows):**
   * Чередующаяся заливка (зебра): четные строки — `#FFFFFF`, нечетные строки — `#F9FAFC`.
   * Шрифт: Times New Roman, **10.0 pt** (полужирный для суммарных строк или ID).
   * Выравнивание: По центру для чисел, дат, статусов; По левому краю для текстовых описаний.
   * Внутренние поля ячеек: `top=80`, `bottom=80`, `left=100`, `right=100` dxa.

---

## 5. Оформление изображений и подписей

Каждое изображение центрируется и снабжается нормативной подписью:

1. **Абзац с рисунком:**
   * Выравнивание: **По центру** (`WD_ALIGN_PARAGRAPH.CENTER`).
   * Ширина изображения: `width=Inches(7.2)` (занимает почти всю доступную ширину страницы при полях 0.5 дюйма).
   * Отбивка: `sb=4.0 pt`, `sa=2.0 pt`.
2. **Абзац с подписью:**
   * Текст: `Рисунок X. <Название рисунка>`
   * Выравнивание: **По центру** (`WD_ALIGN_PARAGRAPH.CENTER`).
   * Шрифт: Times New Roman, **12.0 pt, Обычный** (Regular).
   * Межстрочный интервал: одинарный (None).
   * Отбивка: `sb=2.0 pt`, `sa=8.0 pt`.

---

## 6. Базовый шаблон генерации в Python

```python
import os
import docx
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    shading_xml = f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>'
    cell._tc.get_or_add_tcPr().append(parse_xml(shading_xml))

def set_cell_margins(cell, top=100, bottom=100, left=120, right=120):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('w:top', top), ('w:bottom', bottom), ('w:left', left), ('w:right', right)]:
        node = OxmlElement(m)
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def set_full_table_borders(table, color="A0A0A0", sz="4", val="single"):
    tblPr = table._tbl.tblPr
    borders_xml = f'''
    <w:tblBorders {nsdecls("w")}>
        <w:top w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
        <w:left w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
        <w:bottom w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
        <w:right w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
        <w:insideH w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
        <w:insideV w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>
    </w:tblBorders>
    '''
    tblPr.append(parse_xml(borders_xml))

def create_opd_document():
    doc = docx.Document()
    for s in doc.sections:
        s.page_width = Pt(612.0)
        s.page_height = Pt(792.0)
        s.top_margin = Pt(36.0)
        s.bottom_margin = Pt(36.0)
        s.left_margin = Pt(36.0)
        s.right_margin = Pt(36.0)

    normal_style = doc.styles['Normal']
    normal_style.font.name = 'Times New Roman'
    normal_style.font.size = Pt(14)
    normal_style.paragraph_format.line_spacing = 1.5
    normal_style.paragraph_format.space_before = Pt(0)
    normal_style.paragraph_format.space_after = Pt(2.5)
    return doc
```
