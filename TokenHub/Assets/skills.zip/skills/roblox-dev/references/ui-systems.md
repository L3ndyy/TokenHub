# Roblox UI Systems

> **Source:**
> https://create.roblox.com/docs/ui ·
> https://create.roblox.com/docs/ui/labels ·
> https://create.roblox.com/docs/ui/buttons ·
> https://create.roblox.com/docs/ui/scrolling-frames ·
> https://create.roblox.com/docs/ui/proximity-prompts

> ScreenGui, layout, common elements, 3D-attached UI, animations, and responsive design.

## Table of Contents

1. [ScreenGui Basics](#screengui-basics)
2. [Positioning & Sizing — UDim2](#positioning--sizing--udim2)
3. [Layout Objects](#layout-objects)
4. [Common UI Elements](#common-ui-elements)
5. [3D-Attached UI](#3d-attached-ui)
6. [UI Animations with TweenService](#ui-animations-with-tweenservice)
7. [Responsive Design](#responsive-design)
8. [StarterGui & LocalScript Interaction](#startergui--localscript-interaction)
9. [ProximityPrompt](#proximityprompt)
10. [Best Practices](#best-practices)
11. [UIShadow — Native Drop Shadows](#uishadow--native-drop-shadows)
12. [StyleQuery — Responsive Style Queries (May 2026)](#stylequery--responsive-style-queries-may-2026)
13. [Per-Corner UICorner Rounding](#per-corner-uicorner-rounding)

---

## ScreenGui Basics

A `ScreenGui` is the root container for 2D UI. Place under `StarterGui`; it is
cloned into each player's `PlayerGui` on join (and respawn, unless
`ResetOnSpawn = false`).

| Property | Type | Purpose |
|---|---|---|
| `DisplayOrder` | `number` | Higher values render on top |
| `ResetOnSpawn` | `boolean` | `true` (default) = re-cloned every respawn. `false` for persistent UI |
| `IgnoreGuiInset` | `boolean` | `true` = covers the top bar area. Use for full-screen overlays |
| `Enabled` | `boolean` | Toggle visibility of the entire GUI tree |

<!-- skilltest: prelude local-player; expect hud-gui -->
```luau
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "HUDGui"
screenGui.ResetOnSpawn = false
screenGui.IgnoreGuiInset = true
screenGui.DisplayOrder = 10
screenGui.Parent = player:WaitForChild("PlayerGui") -- a child, not a property: `.PlayerGui` fails --!strict
```

---

## Positioning & Sizing — UDim2

`UDim2.new(xScale, xOffset, yScale, yOffset)` — **Scale** (0–1) is a fraction
of the parent size; **Offset** is fixed pixels added after scale.

```luau
UDim2.fromScale(0.5, 0.5)   -- scale only (offset = 0)
UDim2.fromOffset(200, 100)   -- offset only (scale = 0)
```

**`AnchorPoint`** shifts the origin (0–1 per axis). Center an element:

<!-- skilltest: prelude ui-frames -->
```luau
frame.AnchorPoint = Vector2.new(0.5, 0.5)
frame.Position = UDim2.fromScale(0.5, 0.5)
```

**Rule of thumb:** prefer **Scale** for responsive layout. Use **Offset** for
fixed-pixel elements (icons, padding).

---

## Layout Objects

Layout objects are children of a container and automatically arrange siblings.

### UIListLayout / UIGridLayout

<!-- skilltest: prelude ui-frames -->
```luau
local list = Instance.new("UIListLayout")
list.FillDirection = Enum.FillDirection.Vertical
list.SortOrder = Enum.SortOrder.LayoutOrder
list.Padding = UDim.new(0, 8)
list.Parent = containerFrame

local grid = Instance.new("UIGridLayout")
grid.CellSize = UDim2.fromOffset(100, 100)
grid.CellPadding = UDim2.fromOffset(8, 8)
grid.SortOrder = Enum.SortOrder.LayoutOrder
grid.Parent = containerFrame
```

### Constraints & Utilities

| Object | Purpose |
|---|---|
| `UISizeConstraint` | Clamp min/max pixel size |
| `UITextSizeConstraint` | Clamp min/max text size |
| `UIAspectRatioConstraint` | Lock width:height ratio |
| `UIPadding` | Internal padding on a container |
| `UICorner` | Round corners |
| `UIStroke` | Outline / border |
| `UIFlexItem` | Per-child flex grow/shrink (with UIListLayout) |
| `UIScale` | Uniformly scale a subtree |

### UIFlexItem (Flex Layouts)

`UIFlexItem` enables CSS Flexbox-like behavior when used as a child of a `GuiObject`
that is also a child of a `UIListLayout`. It controls how individual items grow,
shrink, and align within a flex container.

**Properties:**

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `FlexMode` | `Enum.UIFlexMode` | `None` | `None`, `Grow`, `Shrink`, `Fill`, `Custom` |
| `GrowRatio` | `number` | 0 | How much this item grows relative to siblings (when `Custom`) |
| `ShrinkRatio` | `number` | 0 | How much this item shrinks relative to siblings (when `Custom`) |
| `ItemLineAlignment` | `Enum.ItemLineAlignment` | `Automatic` | Cross-axis alignment override for this item |

**Usage:**
<!-- skilltest: prelude ui-frames -->
```lua
-- Make a frame fill remaining space in a horizontal list
local flex = Instance.new("UIFlexItem")
flex.FlexMode = Enum.UIFlexMode.Fill
flex.Parent = myFrame -- myFrame is a child of a UIListLayout parent
```

> **Requirement:** The parent container must have a `UIListLayout` for `UIFlexItem`
> to take effect. Without it, the flex properties are ignored.

---

## Common UI Elements

### TextLabel / TextButton / TextBox

<!-- skilltest: prelude screen-gui -->
```luau
local label = Instance.new("TextLabel")
label.Text = "Score: 0"
label.Font = Enum.Font.GothamBold
label.TextSize = 24
label.TextColor3 = Color3.fromRGB(255, 255, 255)
label.BackgroundTransparency = 1
label.Size = UDim2.fromScale(0.3, 0.05)
label.Parent = screenGui
```

`TextButton` adds `Activated` (preferred) and `MouseButton1Click` events.
`TextBox` adds `FocusLost` for text input.

### ImageLabel / ImageButton

<!-- skilltest: prelude screen-gui -->
```luau
local icon = Instance.new("ImageLabel")
icon.Image = "rbxassetid://123456789"
icon.ScaleType = Enum.ScaleType.Fit
icon.Size = UDim2.fromOffset(48, 48)
icon.BackgroundTransparency = 1
icon.Parent = screenGui
```

### Frame & ScrollingFrame

`Frame` — generic container. `ScrollingFrame` — scrollable container. Set
`AutomaticCanvasSize = Enum.AutomaticSize.Y` so the canvas grows with content.

<!-- skilltest: prelude screen-gui -->
```luau
local scroll = Instance.new("ScrollingFrame")
scroll.Size = UDim2.fromScale(0.4, 0.6)
scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
scroll.ScrollBarThickness = 6
scroll.Parent = screenGui
Instance.new("UIListLayout").Parent = scroll
```

---

## 3D-Attached UI

### BillboardGui (always faces camera)

<!-- skilltest: prelude workspace-props -->
```luau
--@skilltest: project-tree
local billboard = Instance.new("BillboardGui")
billboard.Size = UDim2.fromOffset(200, 50)
billboard.StudsOffset = Vector3.new(0, 3, 0)
billboard.Adornee = workspace.SomeNPC.Head
billboard.Parent = workspace.SomeNPC.Head

local nameLabel = Instance.new("TextLabel")
nameLabel.Size = UDim2.fromScale(1, 1)
nameLabel.BackgroundTransparency = 1
nameLabel.Text = "Shopkeeper"
nameLabel.TextScaled = true
nameLabel.Parent = billboard
```

### SurfaceGui (renders on a Part face)

<!-- skilltest: prelude workspace-props -->
```luau
--@skilltest: project-tree
local surfaceGui = Instance.new("SurfaceGui")
surfaceGui.Face = Enum.NormalId.Front
surfaceGui.PixelsPerStud = 50
surfaceGui.Parent = workspace.TVScreen

local label = Instance.new("TextLabel")
label.Size = UDim2.fromScale(1, 1)
label.Text = "Breaking News"
label.TextScaled = true
label.Parent = surfaceGui
```

---

## UI Animations with TweenService

<!-- skilltest: prelude hud-frame; expect tween-finished -->
```luau
local TweenService = game:GetService("TweenService")

local tweenInfo = TweenInfo.new(
    0.3,                       -- duration
    Enum.EasingStyle.Quad,     -- style
    Enum.EasingDirection.Out   -- direction
)

local frame: Frame = screenGui.HUDFrame
frame.BackgroundTransparency = 1

local tween = TweenService:Create(frame, tweenInfo, {
    BackgroundTransparency = 0,
    Position = UDim2.fromScale(0.5, 0.5),
})
tween:Play()
tween.Completed:Wait()
```

**Tweenable UI properties:** `Position`, `Size`, `BackgroundTransparency`,
`BackgroundColor3`, `TextTransparency`, `ImageTransparency`, `Rotation`,
`GroupTransparency` (on `CanvasGroup` — tween it to fade an entire subtree).

> **`Enum.EasingStyle.Spring` and `Bezier` exist but cannot be used.** Engine 0.744 added both
> items, and in Studio 0.744.0.7441077 `TweenInfo.new(0.3, Enum.EasingStyle.Spring)` and
> `TweenService:GetValue(…, Enum.EasingStyle.Spring, …)` error with `does not support
> Enum.EasingStyle.Spring or Enum.EasingStyle.Bezier`, and `UIPageLayout.EasingStyle = Spring`
> silently stays `Back`. For a springy feel today, use `Elastic` or `Back`, or animate the value
> yourself on `RenderStepped`.

---

## Responsive Design

Use `UDim2.fromScale()` for responsive sizing. Use `UIAspectRatioConstraint`
to lock ratio. Detect device and adapt:

<!-- skilltest: prelude ui-frames -->
```luau
local UIS = game:GetService("UserInputService")
local isMobile = UIS.TouchEnabled and not UIS.KeyboardEnabled

local camera = workspace.CurrentCamera
camera:GetPropertyChangedSignal("ViewportSize"):Connect(function()
    local vp = camera.ViewportSize
    inventoryFrame.Size = if vp.Y > vp.X
        then UDim2.fromScale(0.9, 0.4)
        else UDim2.fromScale(0.4, 0.8)
end)
```

---

## StarterGui & LocalScript Interaction

UI code runs on the **client** in `LocalScripts`.

```luau
--!strict
-- ShopController (LocalScript under ShopGui)
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local shopGui = playerGui:WaitForChild("ShopGui")
local shopFrame = shopGui:WaitForChild("ShopFrame")
local itemTemplate = shopFrame:WaitForChild("ItemTemplate") :: Frame
local PurchaseRemote = ReplicatedStorage:WaitForChild("PurchaseItem") :: RemoteEvent

local function createItemEntry(itemName: string, price: number)
    local entry = itemTemplate:Clone()
    entry.Name = itemName
    entry.Visible = true
    -- Bind to locals: a line that starts with "(" after a statement is "Ambiguous syntax" in Luau
    -- and the whole script fails to compile (an earlier version of this example did exactly that).
    local nameLabel = entry:FindFirstChild("NameLabel") :: TextLabel
    local priceLabel = entry:FindFirstChild("PriceLabel") :: TextLabel
    nameLabel.Text = itemName
    priceLabel.Text = `{price} coins`
    local buyButton = entry:FindFirstChild("BuyButton") :: TextButton
    buyButton.Activated:Connect(function()
        PurchaseRemote:FireServer(itemName)
    end)
    entry.Parent = shopFrame
end
```

---

## ProximityPrompt

Interaction UI when a player is near a Part — Roblox renders it automatically.

<!-- skilltest: prelude workspace-props -->
```luau
--@skilltest: project-tree
local prompt = Instance.new("ProximityPrompt")
prompt.ObjectText = "Treasure Chest"
prompt.ActionText = "Open"
prompt.MaxActivationDistance = 10
prompt.HoldDuration = 0.5
prompt.RequiresLineOfSight = true
prompt.Parent = workspace.TreasureChest

prompt.Triggered:Connect(function(player: Player)
    print(player.Name .. " opened the chest")
end)
```

For custom styling: set `prompt.Style = Enum.ProximityPromptStyle.Custom` and
listen to `ProximityPromptService.PromptShown` / `PromptHidden`.

---

## Best Practices

**Organization:**
- One `ScreenGui` per logical feature (HUD, Shop, Settings). Control layering
  with `DisplayOrder`.
- Name everything descriptively — `HealthBarFrame`, not `Frame`.
- Use ModuleScripts for UI logic; keep LocalScripts thin.

**Performance:**
- Avoid creating/destroying UI every frame — toggle `Visible` or object pool.
- Use `CanvasGroup` to batch-render complex subtrees.
- Minimize `TextScaled` on many labels — prefer explicit `TextSize`.
- Set `Parent` last when building UI trees in code.

**Cleanup:**

<!-- skilltest: prelude button-handlers; expect connections-cleaned -->
```luau
local connections: { RBXScriptConnection } = {}
table.insert(connections, button.Activated:Connect(onActivated))
table.insert(connections, RunService.Heartbeat:Connect(onHeartbeat))

-- On cleanup (player leave, ScreenGui destroyed):
for _, conn in connections do
    conn:Disconnect()
end
```

- Disconnect all event connections to prevent memory leaks.
- `ResetOnSpawn = true` (default) destroys and re-clones the ScreenGui — any
  references to the old copy will break.

---

## UIShadow — Native Drop Shadows

`UIShadow` renders a native drop shadow beneath its parent `GuiObject`,
replacing image-based shadow workarounds. Add as a child of any `GuiObject`.

| Property | Type | Purpose |
|---|---|---|
| `Color` | `Color3` | Shadow color |
| `Transparency` | `number` | `0` = opaque, `1` = invisible |
| `BlurRadius` | `UDim` | Blur softness. Scale is relative to the shorter parent axis |
| `Offset` | `UDim2` | Shifts the shadow relative to the parent position |
| `Spread` | `UDim2` | Expands or shrinks the shadow relative to the parent size |
| `ZIndex` | `number` | Render order among sibling `UIShadow` instances (negative values only) |
| `Enabled` | `boolean` | Toggle shadow visibility (default `true`) |
| `Mode` | `Enum.ApplyShadowMode` | `Shape` (default) or `Text` — *Upgraded UIShadows beta* |
| `Inset` | `boolean` | Shadow inside the parent instead of behind (default `false`) — *beta* |
| `ShowBehindParent` | `boolean` | `false` masks the shadow behind a transparent parent (default `true`) — *beta* |

**Key behaviors:**
- Automatically respects `UICorner` rounding on the parent.
- Rotates with the parent's `Rotation` property.
- Multiple `UIShadow` children are supported; order via `ZIndex`.

**Upgraded UIShadows (Studio beta, documented 2026-10-13):** the UI guide (*Appearance
modifiers → Shadow*) now describes text shadows (`Mode = Enum.ApplyShadowMode.Text` follows the
glyphs of a `TextLabel`, `TextButton` or `TextBox`), inset shadows, `ShowBehindParent`, and a
`UIGradient` child that colors the shadow — behind **File ⟩ Beta Features ⟩ Upgraded UIShadows**.
The three properties are in the 0.742 API dump. In Studio 0.742 a plugin, a server `Script` and a
`LocalScript` each set and read back `Mode = Text`, `Inset`, `ShowBehindParent` and a `UIGradient`
child without error — so a write succeeding does **not** tell you the beta is on; whether they
render without the beta or in a published game was not checked. Since 2026-10-15 the `UIShadow`
class reference documents them too (without a beta notice), and its only remaining limits are
`Path2D` and textures; the UI guide still marks them as the beta. Treat them like any Studio beta: do not rely on them in a published game
until the beta is released.

**Limitations (without the beta):**
- Does **not** render text-shaped shadows — only the rectangular bounding box.
- Does **not** support inset shadows.
- Cannot apply `UIGradient` to a `UIShadow`.
- Does **not** work with `Path2D` (the beta does not change this).

<!-- skilltest: prelude screen-gui; expect ui-shadow -->
```luau
--!strict
-- Add a soft drop shadow to a card Frame
local card = Instance.new("Frame")
card.Name = "CardFrame"
card.Size = UDim2.fromScale(0.3, 0.4)
card.AnchorPoint = Vector2.new(0.5, 0.5)
card.Position = UDim2.fromScale(0.5, 0.5)
card.BackgroundColor3 = Color3.fromRGB(30, 30, 30)

-- Round corners
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 12)
corner.Parent = card

-- Drop shadow (inherits the rounded corners)
local shadow = Instance.new("UIShadow")
shadow.Color = Color3.fromRGB(0, 0, 0)
shadow.Transparency = 0.5
shadow.BlurRadius = UDim.new(0, 16)
shadow.Offset = UDim2.fromOffset(0, 4)
shadow.Parent = card

card.Parent = screenGui
```

**Legacy comparison — before `UIShadow`:**

<!-- skilltest: prelude ui-frames -->
```luau
-- OLD approach: 9-slice ImageLabel behind the frame
local shadowImage = Instance.new("ImageLabel")
shadowImage.Image = "rbxassetid://SHADOW_ASSET_ID"
shadowImage.ScaleType = Enum.ScaleType.Slice
shadowImage.SliceCenter = Rect.new(24, 24, 232, 232)
shadowImage.Size = UDim2.new(1, 20, 1, 20)
shadowImage.Position = UDim2.fromOffset(-10, -6)
shadowImage.BackgroundTransparency = 1
shadowImage.Parent = card  -- layered behind content

-- NEW approach: one line of UIShadow (shown above)
```

### UIGradient shapes — the Upgraded UIGradients beta (October 2026)

Since 2026-10-15 the UI guide (*Appearance modifiers → Gradient*) documents `UIGradient.Type`
(`Enum.GradientType.Linear` / `Radial` / `Elliptical` / `Conical`), `Scale` and `TileMode`
(`Enum.GradientTileMode.Clamp` / `Repeat` / `Mirror`), each behind **File ⟩ Beta Features ⟩
Upgraded UIGradients**. All three are `NotBrowsable` in the 0.743 API dump (hidden from the
Properties window). In Studio 0.743 a `LocalScript` set and read back `Type = Elliptical`,
`Scale` and `TileMode = Mirror` without error, so a successful write does **not** mean the beta is
on, and rendering was not checked. As with the UIShadow beta: build on the default linear gradient
for a published game, and use these only while experimenting in Studio until the beta is released.

---

## StyleQuery — Responsive Style Queries (May 2026)

Fully released 2026-05-11 (staff update to "[Full Release] StyleQuery + More Styling Features!");
it had been a Studio beta since 2026-04-09.

`StyleQuery` enables CSS-like conditional styling for Roblox UI. It works with
the `StyleRule` system to dynamically activate styles based on device,
container size, or accessibility settings.

A `StyleQuery` is an `Instance` you parent under a style sheet. When all its
conditions are `true`, any `StyleRule` using the `@QueryName` selector becomes
active.

### Available Conditions

| Condition | Type | Evaluates to `true` when… |
|---|---|---|
| `MinSize` | `Vector2` | Parent `AbsoluteSize` ≥ `MinSize` |
| `MaxSize` | `Vector2` | Parent `AbsoluteSize` < `MaxSize` |
| `AspectRatioRange` | `NumberRange` | Parent width/height ratio is within the range |
| `ViewportDisplaySize` | `Enum.DisplaySize` | Matches `GuiService.ViewportDisplaySize` |
| `PreferredInput` | `Enum.PreferredInput` | Matches `UserInputService.PreferredInput` |
| `PreferredTextSize` | `Enum.PreferredTextSize` | Matches `GuiService.PreferredTextSize` |
| `ReducedMotionEnabled` | `boolean` | Matches `GuiService.ReducedMotionEnabled` |

### API Methods

| Method | Description |
|---|---|
| `SetCondition(name: string, value: Variant)` | Set a single condition |
| `SetConditions(conditions: {[string]: Variant})` | Set multiple conditions at once |
| `GetCondition(name: string): Variant` | Read a condition's current value |
| `GetConditions(): {[string]: Variant}` | Read all conditions |

`StyleQuery.IsActive` (read-only `boolean`) — `true` when all conditions match.

### Scripted Example: Responsive Container Query

<!-- skilltest: prelude style-sheet -->
```luau
--!strict
-- Create a StyleQuery that activates for narrow containers (< 400px wide)
local narrowQuery = Instance.new("StyleQuery")
narrowQuery.Name = "NarrowContainer"
narrowQuery:SetCondition("MaxSize", Vector2.new(400, math.huge))
narrowQuery.Parent = styleSheet  -- parent to your StyleSheet/StyleRule tree

-- Any StyleRule with Selector = "@NarrowContainer" will activate
-- when the parent container's AbsoluteSize.X < 400
```

### Scripted Example: Multi-Condition Query (Mobile + Touch)

<!-- skilltest: prelude style-sheet -->
```luau
--!strict
-- Activate styles for small-screen touch devices
local mobileQuery = Instance.new("StyleQuery")
mobileQuery.Name = "MobileTouch"
mobileQuery:SetConditions({
    ["ViewportDisplaySize"] = Enum.DisplaySize.Small,
    ["PreferredInput"] = Enum.PreferredInput.Touch,
})
mobileQuery.Parent = styleSheet

-- StyleRules with Selector = "@MobileTouch" now auto-activate on mobile
```

### Built-in Selectors

Roblox provides pre-configured selectors you can use in `StyleRule.Selector`
without creating your own `StyleQuery` instances:

- `@PreferredTextSizeLarge` — active when the player has selected large text
- `@WideContainer` — active when the parent container is wide

### Style Editor Improvements (Studio)

- **Folder organization**: Group related `StyleRule` instances into folders.
- **Smart search**: Filter style rules by name, selector, or property.
- **Auto-populated selectors**: The editor suggests selectors like
  `@PreferredTextSizeLarge` when creating new rules.

### StyleSheet & StyleRule Architecture

`StyleSheet` and `StyleRule` provide a cascading style system similar to CSS.
A `StyleSheet` is parented to a `ScreenGui` (or any `GuiObject`) and contains
`StyleRule` children that match UI elements via `StyleQuery` selectors.

**Hierarchy:**
```
ScreenGui
├─ StyleSheet
│   ├─ StyleRule (Selector: ".button")
│   │   ├─ StyleQuery (matches Tag "button")
│   │   └─ Property overrides (BackgroundColor3, etc.)
│   └─ StyleRule (Selector: ".header")
├─ Frame
│   └─ TextButton (Tag: "button")
```

**Key points:**
- `StyleSheet` must be a descendant of the UI tree it styles
- `StyleRule` children are evaluated in order (later rules override earlier ones)
- Selectors use `CollectionService` tags for matching
- Properties set directly on instances override stylesheet values

---

## Per-Corner UICorner Rounding

`UICorner` now supports individual corner radii, enabling asymmetric rounding
(e.g. tabs, chat bubbles, notification toasts).

| Property | Type | Purpose |
|---|---|---|
| `CornerRadius` | `UDim` | **Shorthand** — sets all four corners at once; reads from `TopLeftRadius` |
| `TopLeftRadius` | `UDim` | Top-left corner radius |
| `TopRightRadius` | `UDim` | Top-right corner radius |
| `BottomRightRadius` | `UDim` | Bottom-right corner radius |
| `BottomLeftRadius` | `UDim` | Bottom-left corner radius |

> **Note:** Per-corner rounding and `UIShadow` are **fully released and publishable** since
> 2026-06-23 ("[Full Release] New UI Capabilities: Shadows & Individual Corners!", Roblox staff
> update), and the "New UI Capabilities" Studio beta flag was removed. The official `UICorner`
> reference still says "currently in beta" (checked 2026-10-11); the staff post is newer. In
> Studio 0.742 a LocalScript set and read back all four properties. Writing to `CornerRadius`
> overwrites all four individual values.

<!-- skilltest: prelude screen-gui; expect per-corner-radius -->
```luau
--!strict
-- Chat bubble: rounded on top, flat on bottom-left
local bubble = Instance.new("Frame")
bubble.Name = "ChatBubble"
bubble.Size = UDim2.fromOffset(260, 80)
bubble.BackgroundColor3 = Color3.fromRGB(45, 45, 48)
bubble.Parent = screenGui

local corner = Instance.new("UICorner")
corner.TopLeftRadius = UDim.new(0, 16)
corner.TopRightRadius = UDim.new(0, 16)
corner.BottomRightRadius = UDim.new(0, 16)
corner.BottomLeftRadius = UDim.new(0, 0)  -- flat corner
corner.Parent = bubble
```

**Legacy comparison — uniform rounding only:**

<!-- skilltest: prelude ui-frames -->
```luau
-- OLD: all corners identical
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 16)
corner.Parent = frame

-- NEW: per-corner control (shown above)
```

**Tip:** When using the styling system (`StyleRule`), avoid setting both
`CornerRadius` and individual corner properties in the same rule — this may
produce unexpected results.
