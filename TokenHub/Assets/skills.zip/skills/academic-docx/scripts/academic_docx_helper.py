# -*- coding: utf-8 -*-
"""
Academic DOCX Helper Module
Standardized tools for creating academic and professional DOCX documents in Python
conforming to Russian GOST (ГОСТ 7.32-2017) and Multiwork requirements.
Includes native Word Auto-TOC (w:sdt), proper styles, tables, formula formatting,
and Word COM synchronization.
"""

import os
import xml.sax.saxutils as saxutils
import docx
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

def setup_document_geometry(doc):
    """
    Sets up standard Russian academic page geometry:
    - A4 Portrait (210 x 297 mm)
    - Left margin: 30 mm (3.0 cm)
    - Right margin: 15 mm (1.5 cm)
    - Top margin: 20 mm (2.0 cm)
    - Bottom margin: 20 mm (2.0 cm)
    - Different first page header/footer (title page has no visible page number)
    - Bottom-center page numbering starting from 1 (first visible on page 2)
    """
    for sec in doc.sections:
        sec.page_width = Cm(21.0)
        sec.page_height = Cm(29.7)
        sec.left_margin = Cm(3.0)
        sec.right_margin = Cm(1.5)
        sec.top_margin = Cm(2.0)
        sec.bottom_margin = Cm(2.0)
        sec.different_first_page_header_footer = True
        
        # Bottom-center page numbering on normal pages
        footer = sec.footer
        p_ft = footer.paragraphs[0]
        p_ft.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_ft.paragraph_format.first_line_indent = Cm(0)
        p_ft.paragraph_format.line_spacing = 1.0
        p_ft.paragraph_format.space_before = Pt(0)
        p_ft.paragraph_format.space_after = Pt(0)
        
        run_ft = p_ft.add_run()
        run_ft.font.name = "Times New Roman"
        run_ft.font.size = Pt(12)
        run_ft.font.color.rgb = RGBColor(0, 0, 0)
        
        fld1 = parse_xml(r'<w:fldChar %s w:fldCharType="begin"/>' % nsdecls('w'))
        fld2 = parse_xml(r'<w:instrText %s xml:space="preserve"> PAGE </w:instrText>' % nsdecls('w'))
        fld3 = parse_xml(r'<w:fldChar %s w:fldCharType="separate"/>' % nsdecls('w'))
        fld4 = parse_xml(r'<w:fldChar %s w:fldCharType="end"/>' % nsdecls('w'))
        run_ft._r.extend([fld1, fld2, fld3, fld4])

def setup_academic_styles(doc):
    """
    Configures Normal style and ensures TOC styles exist.
    """
    style_normal = doc.styles['Normal']
    style_normal.font.name = 'Times New Roman'
    style_normal.font.size = Pt(14)
    style_normal.font.color.rgb = RGBColor(0, 0, 0)
    style_normal.paragraph_format.line_spacing = 1.5
    style_normal.paragraph_format.first_line_indent = Cm(1.25)
    style_normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    style_normal.paragraph_format.space_before = Pt(0)
    style_normal.paragraph_format.space_after = Pt(0)

def build_native_sdt_toc(doc, toc_entries):
    """
    Creates a native Word w:sdt block for Table of Contents,
    conforming 100% to Word's internal specification and E:\Диплом.docx.
    toc_entries: list of tuples (title, page_number_str, bookmark_name, level)
                 level 0: main section (bold, indent 0)
                 level 1: subsection (regular, indent 400 dxa)
    """
    sdt = OxmlElement('w:sdt')
    
    # w:sdtPr
    sdtPr = parse_xml(
        f'<w:sdtPr {nsdecls("w")}>'
        f'  <w:docPartObj>'
        f'    <w:docPartGallery w:val="Table of Contents"/>'
        f'    <w:docPartUnique/>'
        f'  </w:docPartObj>'
        f'</w:sdtPr>'
    )
    sdt.append(sdtPr)
    
    # w:sdtEndPr
    sdtEndPr = parse_xml(
        f'<w:sdtEndPr {nsdecls("w")}>'
        f'  <w:rPr>'
        f'    <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
        f'    <w:sz w:val="28"/><w:szCs w:val="28"/>'
        f'  </w:rPr>'
        f'</w:sdtEndPr>'
    )
    sdt.append(sdtEndPr)
    
    sdtContent = OxmlElement('w:sdtContent')
    sdt.append(sdtContent)
    
    # Paragraph 0: Heading "СОДЕРЖАНИЕ"
    p0 = parse_xml(
        f'<w:p {nsdecls("w")}>'
        f'  <w:pPr>'
        f'    <w:pStyle w:val="a4"/>'
        f'    <w:jc w:val="center"/>'
        f'    <w:spacing w:before="0" w:after="240" w:line="360" w:lineRule="auto"/>'
        f'  </w:pPr>'
        f'  <w:r>'
        f'    <w:rPr>'
        f'      <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
        f'      <w:b/>'
        f'      <w:sz w:val="28"/><w:szCs w:val="28"/>'
        f'      <w:color w:val="000000"/>'
        f'    </w:rPr>'
        f'    <w:t>СОДЕРЖАНИЕ</w:t>'
        f'  </w:r>'
        f'</w:p>'
    )
    sdtContent.append(p0)
    
    # Entries
    total = len(toc_entries)
    for idx, (title, page, bmark, level) in enumerate(toc_entries):
        is_first = (idx == 0)
        esc_title = saxutils.escape(title)
        
        ind_xml = '<w:ind w:left="400"/>' if level > 0 else '<w:ind w:left="0"/>'
        pstyle_val = "21" if level > 0 else "11"
        bold_xml = '<w:b/>' if level == 0 and not title.startswith("  ") else ''
        
        p = OxmlElement('w:p')
        pPr = parse_xml(
            f'<w:pPr {nsdecls("w")}>'
            f'  <w:pStyle w:val="{pstyle_val}"/>'
            f'  <w:tabs>'
            f'    <w:tab w:val="right" w:leader="dot" w:pos="9345"/>'
            f'  </w:tabs>'
            f'  <w:spacing w:before="0" w:after="0" w:line="360" w:lineRule="auto"/>'
            f'  {ind_xml}'
            f'  <w:jc w:val="both"/>'
            f'</w:pPr>'
        )
        p.append(pPr)
        
        # First entry contains the TOC field definition
        if is_first:
            fld_begin = parse_xml(
                f'<w:r {nsdecls("w")}><w:rPr><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>'
            )
            fld_instr = parse_xml(
                f'<w:r {nsdecls("w")}><w:rPr><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr><w:instrText xml:space="preserve"> TOC \\o "1-3" \\h \\z \\u </w:instrText></w:r>'
            )
            fld_sep = parse_xml(
                f'<w:r {nsdecls("w")}><w:rPr><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr><w:fldChar w:fldCharType="separate"/></w:r>'
            )
            p.append(fld_begin)
            p.append(fld_instr)
            p.append(fld_sep)
            
        # Hyperlink block
        hlink = parse_xml(
            f'<w:hyperlink {nsdecls("w")} w:anchor="{bmark}" w:history="1">'
            f'  <w:r>'
            f'    <w:rPr>'
            f'      <w:rStyle w:val="a5"/>'
            f'      <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
            f'      {bold_xml}'
            f'      <w:sz w:val="28"/><w:szCs w:val="28"/>'
            f'      <w:color w:val="000000"/>'
            f'    </w:rPr>'
            f'    <w:t>{esc_title}</w:t>'
            f'  </w:r>'
            f'  <w:r>'
            f'    <w:rPr>'
            f'      <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
            f'      <w:webHidden/>'
            f'      <w:sz w:val="28"/><w:szCs w:val="28"/>'
            f'    </w:rPr>'
            f'    <w:tab/>'
            f'  </w:r>'
            f'  <w:r>'
            f'    <w:rPr><w:webHidden/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr>'
            f'    <w:fldChar w:fldCharType="begin"/>'
            f'  </w:r>'
            f'  <w:r>'
            f'    <w:rPr><w:webHidden/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr>'
            f'    <w:instrText xml:space="preserve"> PAGEREF {bmark} \\h </w:instrText>'
            f'  </w:r>'
            f'  <w:r>'
            f'    <w:rPr><w:webHidden/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr>'
            f'    <w:fldChar w:fldCharType="separate"/>'
            f'  </w:r>'
            f'  <w:r>'
            f'    <w:rPr>'
            f'      <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
            f'      <w:webHidden/>'
            f'      {bold_xml}'
            f'      <w:sz w:val="28"/><w:szCs w:val="28"/>'
            f'      <w:color w:val="000000"/>'
            f'    </w:rPr>'
            f'    <w:t>{page}</w:t>'
            f'  </w:r>'
            f'  <w:r>'
            f'    <w:rPr><w:webHidden/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr>'
            f'    <w:fldChar w:fldCharType="end"/>'
            f'  </w:r>'
            f'</w:hyperlink>'
        )
        p.append(hlink)
        sdtContent.append(p)
        
    # Closing paragraph with fldChar end
    p_end = parse_xml(
        f'<w:p {nsdecls("w")}><w:pPr><w:rPr><w:b/></w:rPr></w:pPr><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>'
    )
    sdtContent.append(p_end)
    return sdt

def add_heading_with_bookmark(doc, text, level=1, bmark_name="", is_structural=False, new_page=False, bmark_id=100):
    """
    Adds a heading with a hidden bookmark for TOC navigation:
    - is_structural: Center aligned, bold uppercase, no first line indent (ВВЕДЕНИЕ, ЗАКЛЮЧЕНИЕ, etc.)
    - level 1: Left aligned, 1.25 cm indent, bold uppercase/title case
    - level 2: Left aligned, 1.25 cm indent, bold sentence case
    """
    if new_page:
        doc.add_page_break()
        
    p = doc.add_paragraph()
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.0
    
    if is_structural:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.style = 'Heading 1'
    elif level == 1:
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.first_line_indent = Cm(1.25)
        p.style = 'Heading 1'
    else:
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.first_line_indent = Cm(1.25)
        p.style = 'Heading 2'
        
    if bmark_name:
        bm_start = parse_xml(f'<w:bookmarkStart {nsdecls("w")} w:id="{bmark_id}" w:name="{bmark_name}"/>')
        p._p.append(bm_start)
        
    r = p.add_run(text)
    r.bold = True
    r.font.name = "Times New Roman"
    r.font.size = Pt(14)
    r.font.color.rgb = RGBColor(0, 0, 0)
    
    if bmark_name:
        bm_end = parse_xml(f'<w:bookmarkEnd {nsdecls("w")} w:id="{bmark_id}"/>')
        p._p.append(bm_end)
        
    return p

def sync_document_with_word_com(docx_path):
    """
    Opens document in Microsoft Word via COM, updates all fields (including TOC),
    and saves natively. This avoids any 'document contains fields referencing external files'
    warnings while ensuring 100% accurate page numbers.
    """
    try:
        import win32com.client
        word = win32com.client.Dispatch('Word.Application')
        word.Visible = False
        word.DisplayAlerts = 0
        doc = word.Documents.Open(os.path.abspath(docx_path))
        if doc.TablesOfContents.Count > 0:
            doc.TablesOfContents(1).Update()
        doc.Save()
        doc.Close()
        word.Quit()
        return True
    except Exception as e:
        print(f"Word COM synchronization warning: {e}")
        return False
