---
name: academic-docx
description: Standard instructions, patterns, and code for generating production-grade Russian academic documents (GOST 7.32-2017, Multiwork, diploma/thesis, coursework, laboratory works) in DOCX format with native interactive Word Auto-TOC, exact styles, tables, formula numbering, and bibliography.
---

# Academic DOCX Generation Guide (ГОСТ 7.32 & Мультиворк)

This skill provides comprehensive instructions and reusable python-docx logic to generate Russian academic documents (курсовые работы, ВКР / дипломы, лабораторные работы, бизнес-планы, отчеты по практике) adhering strictly to ГОСТ 7.32-2017 and academic requirements (such as the "Мультиворк" formatting manual).

---

## 1. Core Formatting Rules

| Parameter | Standard Value | Implementation in python-docx |
| :--- | :--- | :--- |
| **Page Size** | A4 Portrait (210 × 297 mm) | `sec.page_width = Cm(21.0)`, `sec.page_height = Cm(29.7)` |
| **Left Margin** | 30 mm (3.0 cm) | `sec.left_margin = Cm(3.0)` |
| **Right Margin** | 15 mm (1.5 cm) | `sec.right_margin = Cm(1.5)` |
| **Top Margin** | 20 mm (2.0 cm) | `sec.top_margin = Cm(2.0)` |
| **Bottom Margin** | 20 mm (2.0 cm) | `sec.bottom_margin = Cm(2.0)` |
| **Main Font** | Times New Roman, 14 pt, Regular | `p.runs[0].font.name = "Times New Roman"`, `Pt(14)` |
| **Line Spacing** | 1.5 lines | `p.paragraph_format.line_spacing = 1.5` |
| **First Line Indent** | 1.25 cm | `p.paragraph_format.first_line_indent = Cm(1.25)` |
| **Text Alignment** | Justified (по ширине) | `p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY` |
| **Page Numbering** | Bottom center, starts at 1 from title, hidden on page 1, visible from page 2 | `sec.different_first_page_header_footer = True`, footer field `PAGE` |

---

## 2. Headings Hierarchy

### Structural Headings (ВВЕДЕНИЕ, ЗАКЛЮЧЕНИЕ, СПИСОК ИСТОЧНИКОВ, ПРИЛОЖЕНИЕ)
- **Positioning**: Always starts on a new page (`new_page=True`).
- **Alignment**: Center-aligned (`WD_ALIGN_PARAGRAPH.CENTER`).
- **First Line Indent**: 0 cm (`Cm(0)`).
- **Case & Weight**: ALL CAPS, Bold, 14 pt.
- **Numbering**: Never numbered.
- **Punctuation**: No period at the end.

### Section Headings (ГЛАВА 1 / 1 НАЗВАНИЕ)
- **Positioning**: Starts on a new page or with 12 pt space before, 6 pt after.
- **Alignment**: Left-aligned with 1.25 cm indent (`WD_ALIGN_PARAGRAPH.LEFT`, `first_line_indent = Cm(1.25)`).
- **Case & Weight**: ALL CAPS or Title Case, Bold, 14 pt.
- **Numbering**: `1 ВЫБОР ИДЕИ СТАРТАПА` (no period after number or heading).
- **Property**: `keep_with_next = True`.

### Subsection Headings (1.1 Название подраздела)
- **Positioning**: 12 pt space before, 6 pt after, does not require a page break.
- **Alignment**: Left-aligned with 1.25 cm indent (`first_line_indent = Cm(1.25)`).
- **Case & Weight**: Sentence Case (с прописной буквы), Bold, 14 pt.
- **Numbering**: `1.1 Определение идеи стартапа` (no trailing period).
- **Property**: `keep_with_next = True`.

---

## 3. Native Word Auto-TOC (w:sdt) Architecture

To match reference documents (like `E:\Диплом.docx`), the Table of Contents MUST be an interactive native Word content control (`w:sdt`), NOT a table or plain text.

### Critical Rules for Word Auto-TOC:
1. **Never set `<w:updateFields w:val="true"/>` in `word/settings.xml`**:
   - Word treats this setting as a potential security risk and displays a blocking alert:
     > *"Документ содержит поля, которые ссылаются на другие файлы. Обновить поля в документе?"*
   - If the user clicks "Нет", Word will refuse to render the field results and the page will appear blank!
2. **Use Native XML Structure (`w:sdt` + `TOC \o "1-3" \h \z \u`)**:
   - Enclose the TOC in `<w:sdt>`.
   - Title `СОДЕРЖАНИЕ` is centered with style `TOC Heading` (or `a4`).
   - Entries use paragraph styles `toc 1` (`11`) and `toc 2` (`21`).
   - First entry opens the field: `<w:fldChar w:fldCharType="begin"/>`, `<w:instrText> TOC \o "1-3" \h \z \u </w:instrText>`, `<w:fldChar w:fldCharType="separate"/>`.
   - Each entry contains a `<w:hyperlink>` pointing to bookmark `_TocXXXX` with text, dot leader tab at `9345 dxa`, and nested `PAGEREF _TocXXXX \h` field with cached page number.
   - SDT concludes with an empty paragraph containing `<w:fldChar w:fldCharType="end"/>`.
3. **Synchronization with Word COM**:
   - On Windows, if Microsoft Word is installed, always finalize the document via COM:
     ```python
     import win32com.client, os
     word = win32com.client.Dispatch('Word.Application')
     word.Visible = False
     word.DisplayAlerts = 0
     doc = word.Documents.Open(os.path.abspath(docx_path))
     if doc.TablesOfContents.Count > 0:
         doc.TablesOfContents(1).Update()
     doc.Save()
     doc.Close()
     word.Quit()
     ```
   - This ensures Word calculates the exact page numbers, bakes in native runs, and opens instantly without any warning popups.

---

## 4. Tables and Visual Elements

- **Table Numbering & Title**:
  - `Таблица 1.1 – Название таблицы`
  - Position: Above the table, left-aligned with paragraph indent (1.25 cm) or from the left margin without indent (depending on department guidelines). No period at the end.
- **Inside Table**:
  - Font: Times New Roman 10–12 pt (single spacing).
  - Cell padding: Top/Bottom 100–120 dxa, Left/Right 150 dxa.
  - Table alignment: Centered on the page.
  - Borders: Thin single black border (`sz="4"`, `val="single"`).

---

## 5. Formulas

- **Layout**:
  - Formula centered on a separate line.
  - Formula number right-aligned in parentheses, e.g., `(1)` or `(4.1)`.
  - Next line starts with `где` without indentation:
    ```text
    (formula centered)                               (1)

    где  Q_BEP – точка безубыточности в натуральном выражении, подписок/мес.;
         FC    – совокупные постоянные затраты стартапа, руб./мес.;
         P     – цена единицы продукции (тарифной подписки), руб./мес.;
         AVC   – средние переменные затраты на одного пользователя, руб./мес.
    ```

---

## 6. Bibliographic List (Список использованных источников)

- Numbered list: `1. `, `2. ` with 1.25 cm first-line indent.
- Standard: ГОСТ Р 7.0.100-2018 / ГОСТ 7.0.5-2008.
- Fresh sources (last 3–5 years) for contemporary economic/IT topics.
- In-text citations formatted as `[1]`, `[2, с. 45]`, `[5, 8]`.

---

## 7. Reusable Code

Import the helper functions from `.agents/skills/academic-docx/scripts/academic_docx_helper.py`:
- `setup_document_geometry(doc)`
- `setup_academic_styles(doc)`
- `build_native_sdt_toc(doc, toc_entries)`
- `add_heading_with_bookmark(doc, text, level, bmark_name, is_structural, new_page, bmark_id)`
- `sync_document_with_word_com(docx_path)`
