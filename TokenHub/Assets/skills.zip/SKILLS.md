# Каталог скиллов OpenCode

Собрано: 19.11.2026
Источник: `C:\Users\nikik\.config\opencode\skills`
Всего скиллов: **158** (423 файла, ~5.1 МБ)

---

## Как перенести на другой компьютер

1. Распаковать архив `skills-backup-2026-11-19.zip`.
2. Скопировать папку `skills` целиком в:
   - Windows: `C:\Users\<имя_пользователя>\.config\opencode\`
   - macOS / Linux: `~/.config/opencode/`
3. Проверить, что получилось `...\.config\opencode\skills\<имя_скилла>\SKILL.md`.
4. Перезапустить OpenCode — скиллы подхватываются автоматически.

Для Claude Code тот же набор кладётся в `~/.claude/skills/`.
Из архива исключены только мусорные `__pycache__` / `*.pyc`, содержимое самих скиллов не тронуто.

Правила работы скилла (если понадобится править) — обычный Markdown с YAML-фронтматтером:

```markdown
---
name: имя-скилла
description: когда применять и что делает
---
```

---

## Документы, презентации, оформление

- **academic-docx** — генерация российских академических документов в DOCX по ГОСТ 7.32-2017: курсовые, дипломы, лабораторные, Multiwork, автособираемое оглавление Word, таблицы, нумерация формул, библиография.
- **opd-word-style** — оформление отчётов по ОПД/практическим работам в Word под конкретный эталон (поля 0.5″, Times New Roman 14, интервал 1.5, таблицы с рамками, подписи к рисункам).
- **pptx** — любые операции с .pptx/.potx: создание колод, чтение и извлечение текста, правка, объединение/разбиение, шаблоны, заметки докладчика.
- **frontend-slides** — анимированные HTML-презентации с нуля или конвертация PowerPoint в веб-слайды.

## Планирование, решения, визуализация

- **council** — «совет» из четырёх ролей для спорных решений и go/no-go, когда есть несколько валидных путей.
- **council-multi-model** — дополнительная внешняя критика (Codex) к уже готовому решению совета; требует явного согласия на отправку данных.
- **dev-team** — имитация командной сессии PM + архитектор + разработчик + QA по одной задаче.
- **product-lens** — продуктовые диагностики: YC-style разбор идеи с go/no-go (PRODUCT-BRIEF.md), оценка product-market fit, аудит user journey, приоритизация фич по ICE.
- **intent-driven-development** — превращение размытого запроса в проверяемые критерии приёмки до начала кода.
- **karpathy-guidelines** — поведенческие правила против типичных ошибок LLM: не усложнять, делать хирургические правки, озвучивать допущения, задавать проверяемые цели.
- **goal** — постановка цели, которую агент доводит до конца.
- **plan-canvas** — план или HTML-артефакт в локальном браузере, где человек комментирует элементы и подтверждает изменения.
- **canvas** — живой React-артефакт рядом с чатом для аналитики, таблиц, графиков, таймлайнов и интерактивных разборов.
- **visualize** — компактные схемы и графики прямо в чате (Mermaid, таблицы, inline HTML).

## Работа с ИИ-агентами и самообучение

- **agent-introspection-debugging** — разбор провала агента по схеме «зафиксировать → диагностировать → восстановиться → отчёт» вместо слепого ретрая.
- **agent-self-evaluation** — самооценка результата по 5 критериям после нетривиальной задачи (точность, полнота, ясность, применимость, краткость).
- **agent-sort** — ревизия установки ECC под конкретный репозиторий: что нужно каждый день, а что держать в библиотеке.
- **continuous-learning** — (устарел, заменён v2) старый извлекатель уроков из сессии.
- **continuous-learning-v2** — инстинкты с оценкой уверенности и привязкой к проекту, выращивание их в скиллы/команды/агентов.
- **growth-log** — записи о полученных уроках в формате «причина → переносимое правило → сигнал», без дневникового пересказа.
- **eval-harness** — eval-driven разработка: критерии pass/fail до кода, грейдеры, pass@k и pass^k, регрессионные наборы для агентов.
- **skill-comply** — проверка, реально ли агент соблюдает скиллы и правила: генерация сценариев, прогон, отчёт о проценте соблюдения.
- **skill-stocktake** — аудит качества скиллов и команд (быстрый скан изменённых или полный обход через субагентов).
- **skill-scout** — поиск готового скилла в локальных, маркетплейсных и GitHub-источниках до создания своего.
- **rules-distill** — вынесение повторяющихся сквозных принципов из скиллов в отдельные файлы правил.
- **santa-method** — состязательная проверка двумя независимыми ревьюерами по одному рубрикатору с циклом доработки.
- **strategic-compact** — подсказка сжимать контекст в логические моменты, а не когда он уже переполнен.
- **context-budget** — аудит расхода контекстного окна агентами, скиллами, MCP и правилами с планом экономии токенов.
- **config-gc** — «сборка мусора» в конфиге агента: устаревшие скиллы, хуки, кеши, лишние права — с подтверждением каждого удаления.
- **delivery-gate** — стоп-хук, который не даёт объявить работу готовой, пока не пройдены проверки качества и фиксация уроков.
- **unified-memory** — общая память и передача контекста между Claude, Codex, Cursor, OpenCode и другими агентами.
- **ck** — постоянная память проекта (Context Keeper): init/save/resume/info/list и бриф проекта на старте сессии.
- **iterative-retrieval** — пошаговое уточнение поиска контекста, когда субагенту не хватает информации.

## Качество кода, процесс, ревью

- **coding-standards** — базовые сквозные соглашения: нейминг, читаемость, иммутабельность, критерии ревью.
- **tdd-workflow** — TDD-цикл: падающий тест → минимальная реализация → рефакторинг, покрытие 80%+.
- **verification-loop** — шесть фаз проверки работы: сборка, типы, линт, тесты с покрытием, security-grep, ревью диффа.
- **code-tour** — файлы CodeTour: пошаговые экскурсии по коду с привязкой к файлам и строкам для онбординга и PR.
- **codebase-onboarding** — разбор незнакомого проекта: карта архитектуры, точки входа, конвенции, стартовый CLAUDE.md.
- **architecture-decision-records** — решения в виде ADR в `docs/adr/` с контекстом, альтернативами и последствиями.
- **living-docs-governance** — защита документации долгого проекта от расползания: роли доков, карта, статус, история.
- **inherit-legacy-style** — предотвращение стилевого дрейфа на legacy: выявление неявных конвенций и `.ai-style-rules.md` с Golden Files.
- **error-handling** — типизированные ошибки, ретраи, circuit breaker, error boundaries, тексты ошибок для пользователя (TS/Python/Go).
- **api-design** — REST: ресурсы, коды ответов, пагинация, фильтры, ошибки, версионирование, лимиты.
- **hexagonal-architecture** — порты и адаптеры, чистые границы домена, инверсия зависимостей в TS/Java/Kotlin/Go.
- **contract-first** — единый контракт (OpenAPI/AsyncAPI/Protobuf/JSON Schema) как источник типов для фронта и бэка.
- **ai-regression-testing** — регрессионные тесты для кода, написанного ИИ: sandbox-режим без БД, проверка «слепых зон».
- **production-audit** — локальный аудит готовности к продакшену: что сломается, без отправки кода наружу.
- **click-path-audit** — трассировка каждого клика/кнопки по всей цепочке состояний, чтобы найти баги «по отдельности работает».
- **plankton-code-quality** — автоформат, линт и автофиксы на каждое сохранение файла через хуки.
- **codehealth-mcp** — Code Health через CodeScene MCP: проверка до правок и дельта после, гейт на коммит/PR.
- **review** — ревью изменений через субагентов Bugbot или Security Review.
- **review-bugbot** — ревью кода субагентом Bugbot.
- **review-security** — ревью кода субагентом Security Review.
- **split-to-prs** — разбиение текущей работы на маленькие ревьюабельные PR.
- **git-workflow** — ветвление, конвенции коммитов, чистка истории перед PR, merge vs rebase, разрешение конфликтов.
- **database-migrations** — безопасные и обратимые миграции: expand-contract, конкурентные индексы, батч-бэкфилл, rollback.
- **accessibility** — доступность UI по WCAG 2.2 AA для Web/iOS/Android: ARIA, фокус, контраст, скринридеры.
- **repo-scan** — указатель на внешний скилл-аудит исходников (кросс-стек разбор ассетов кода).
- **autopilot** — доведение PR до merge-ready: разбор комментариев, конфликты, починка CI в цикле.

## Frontend

- **frontend-patterns** — паттерны React/Next.js: состояние, производительность, UI-практики.
- **frontend-a11y** — доступность в React/Next.js: семантика, ARIA, подписи форм, клавиатура, фокус, модалки, табы.
- **frontend-design-direction** — дизайн-направление для продуктового UI: сайты, дашборды, лендинги, компоненты.
- **react-patterns** — React 18/19: дисциплина хуков, границы server/client, Suspense и error boundaries, формы, выбор стейт-менеджера.
- **react-performance** — 70+ правил оптимизации React/Next.js по 8 категориям (waterfalls, бандл, рендер, ре-рендер и т.д.).
- **react-testing** — тесты компонентов: React Testing Library, Vitest/Jest, MSW, axe, граница между юнит- и e2e-тестами.
- **react-native-patterns** — React Native/Expo: Expo Router, разделение состояния, TanStack Query + Zod, списки, NativeWind, secure storage.
- **nextjs-turbopack** — Next.js 16+ и Turbopack: кеш, скорость dev/HMR, отличия от webpack, `proxy.ts` вместо `middleware.ts`.
- **nuxt4-patterns** — Nuxt 4: гидратация, route rules, lazy loading, SSR-safe `useFetch`/`useAsyncData`.
- **vue-patterns** — Vue 3 Composition API, Pinia, Vue Router, SSR-паттерны Nuxt.
- **ui-to-vue** — пакетная конвертация скриншотов/макетов в компоненты Vue 3 (Vant, Element Plus, Ant Design Vue).
- **angular-developer** — Angular: сигналы, linkedSignal, resource, формы, DI, роутинг, SSR, ARIA, анимации, Tailwind, тесты, CLI.
- **vite-patterns** — Vite: конфиг, плагины, HMR, env, proxy, SSR, library mode, оптимизация сборки.
- **make-interfaces-feel-better** — доводка интерфейса «на ощупь»: отступы, типографика, границы, тени, движение, зоны нажатия, иконки.
- **design-system** — дизайн-система из существующего кода: токены, DESIGN.md, HTML-превью, оценка UI по 10 шкалам, поиск «ИИ-слопа».
- **motion-foundations** — база анимаций motion/react: токены, пружины, производительность, reduced-motion, SSR.
- **motion-patterns** — готовые анимации: кнопка, модалка, тост, stagger, переходы страниц, выход, скролл, layout.
- **motion-advanced** — drag&drop, жесты, анимация текста и SVG-путей, кастомные хуки, useAnimate. Требует motion-foundations.
- **browser-qa** — пост-деплой проверка UI в браузере: ошибки консоли, Core Web Vitals, формы и авторизация, визуальная регрессия на 3 брейкпоинтах, axe, вердикт SHIP / DO NOT SHIP.
- **e2e-testing** — Playwright: Page Object Model, конфиг, CI, артефакты, борьба с флаки-тестами.
- **bun-runtime** — Bun как рантайм, пакетный менеджер, бандлер и тест-раннер; миграция с Node; поддержка на Vercel.
- **i18n-sync** — перевод и синхронизация JSON-локальей: ключи, терминология проекта, поиск пропусков и устаревших строк.

## Backend

- **backend-patterns** — архитектура бэкенда, API, оптимизация БД и серверные практики для Node.js/Express/Next.js API routes.
- **nestjs-patterns** — NestJS: модули, контроллеры, провайдеры, DTO-валидация, guard'ы, интерсепторы, конфиг.
- **fastapi-patterns** — FastAPI: структура проекта, Pydantic v2, DI, async-хендлеры, auth, транзакции, тесты.
- **django-patterns** — Django: архитектура, DRF, ORM, кеш, сигналы, middleware, прод-настройки.
- **django-celery** — Celery в Django: конфиг, задачи, beat, ретраи, canvas, мониторинг, тесты.
- **django-tdd** — тесты Django/DRF: pytest-django, factory_boy, моки, покрытие, TDD.
- **django-verification** — проверка Django-проекта: mypy/ruff/black, безопасность миграций, pytest с покрытием, pip-audit, bandit.
- **laravel-patterns** — Laravel: роутинг, контроллеры, Eloquent, сервисный слой, очереди, события, кеш, API resources.
- **laravel-tdd** — тесты Laravel: PHPUnit/Pest, фабрики, HTTP-тесты, Sanctum, моки, покрытие.
- **laravel-verification** — проверка Laravel-проекта: env, линт, статанализ, тесты, security-скан, готовность к деплою.
- **laravel-plugin-discovery** — поиск и оценка Laravel-пакетов через LaraPlugins.io MCP: здоровье пакета, совместимость с PHP.
- **rails-patterns** — Rails 7.1/8.x: тонкие контроллеры, service/form/query objects, ActiveRecord, фоновые задачи, ViewComponent, Hotwire, Solid-стек.
- **springboot-patterns** — Spring Boot: слои, REST, доступ к данным, кеш, async, логирование.
- **springboot-tdd** — TDD в Spring Boot: JUnit 5, Mockito, MockMvc, Testcontainers, JaCoCo.
- **springboot-verification** — проверка Spring Boot: сборка Maven/Gradle, SpotBugs/PMD/Checkstyle, тесты с Testcontainers, OWASP-скан, ревью диффа.
- **jpa-patterns** — JPA/Hibernate: сущности, связи, оптимизация запросов, транзакции, аудит, индексы, пагинация, пулинг, N+1.
- **java-coding-standards** — Java для Spring Boot/Quarkus: нейминг, иммутабельность, Optional, стримы, исключения, генерики, CDI, реактивность.
- **quarkus-patterns** — Quarkus 3.x LTS: Camel для сообщений, REST, CDI, Panache, async, событийные архитектуры.
- **quarkus-tdd** — TDD в Quarkus: JUnit 5, Mockito, REST Assured, тесты Camel, JaCoCo.
- **quarkus-verification** — проверка Quarkus: сборка, Checkstyle/PMD/SpotBugs, тесты с покрытием, OWASP, native-сборка GraalVM, health-check.
- **dotnet-patterns** — идиоматичный C#/.NET: DI, async/await, конвенции, поддерживаемость.
- **mcp-server-patterns** — создание MCP-серверов на Node/TypeScript SDK: tools, resources, prompts, Zod, stdio vs Streamable HTTP.
- **tinystruct-patterns** — фреймворк tinystruct (Java): Application-классы, @Action-роуты, ActionRegistry, HTTP/CLI, SSE, загрузка файлов.

## Языки и мобильная разработка

- **python-patterns** — Python: PEP 8, идиомы, type hints, поддерживаемая структура кода.
- **python-testing** — pytest: фикстуры, моки, параметризация, TDD, требования к покрытию.
- **golang-patterns** — идиоматичный Go: структура, конвенции, эффективность, поддерживаемость.
- **golang-testing** — Go-тесты: табличные, subtests, бенчмарки, фаззинг, покрытие.
- **rust-patterns** — Rust: владение, обработка ошибок, трейты, конкурентность.
- **rust-testing** — тесты Rust: unit, интеграционные, async, property-based, моки, покрытие.
- **kotlin-patterns** — Kotlin: идиомы, null-safety, корутины, DSL-билдеры.
- **kotlin-testing** — тесты Kotlin: Kotest, MockK, тестирование корутин, property-based, Kover.
- **kotlin-coroutines-flows** — корутины и Flow: structured concurrency, операторы, StateFlow, отмена, ошибки, тесты.
- **kotlin-ktor-patterns** — Ktor: routing DSL, плагины, auth, Koin DI, kotlinx.serialization, WebSockets, testApplication.
- **kotlin-exposed-patterns** — Exposed ORM: DSL/DAO, транзакции, HikariCP, Flyway, репозитории.
- **android-clean-architecture** — Clean Architecture для Android/KMP: модули, правила зависимостей, UseCase, репозитории, data-слой.
- **compose-multiplatform-patterns** — Compose Multiplatform/Jetpack Compose: состояние, навигация, темы, производительность.
- **dart-flutter-patterns** — Dart/Flutter: null-safety, Freezed, BLoC/Riverpod/Provider, GoRouter с auth-guard, Dio, ошибки, тесты.
- **flutter-dart-code-review** — чек-лист ревью Flutter/Dart: виджеты, стейт-менеджеры, идиомы, производительность, a11y, безопасность, архитектура.
- **cpp-coding-standards** — C++ по Core Guidelines: современный безопасный идиоматичный код.
- **cpp-testing** — тесты C++: GoogleTest/CTest, флаки, покрытие, санитайзеры.
- **csharp-testing** — тесты C#/.NET: xUnit, FluentAssertions, моки, интеграционные тесты.
- **fsharp-testing** — тесты F#: xUnit, FsUnit, Unquote, FsCheck, интеграционные.
- **perl-patterns** — современный Perl 5.36+: идиомы и конвенции.
- **perl-testing** — тесты Perl: Test2::V0, Test::More, prove, моки, Devel::Cover.
- **windows-desktop-e2e** — E2E-тесты нативных Windows-приложений (WPF, WinForms, Win32/MFC, Qt) через pywinauto и UI Automation.
- **generating-python-installer** — коммерческая упаковка Python под Windows: Nuitka, урезание dist, анализ DLL, Inno Setup, минимальный и быстрый установщик.

## Базы данных и кэш

- **postgres-patterns** — PostgreSQL: оптимизация запросов, схемы, индексы, RLS, безопасность (по практикам Supabase).
- **mysql-patterns** — MySQL/MariaDB: схемы, запросы, индексы, транзакции, репликация, пулинг соединений.
- **clickhouse-io** — ClickHouse: схемы, оптимизация запросов, аналитика, инженерия данных.
- **redis-patterns** — Redis: структуры данных, кеширование, распределённые локи, rate limiting, pub/sub, соединения.
- **prisma-patterns** — Prisma: схема, запросы, транзакции, пагинация и типичные грабли (`updateMany` возвращает count, таймауты `$transaction`, `migrate dev` сбрасывает БД, `@updatedAt` при bulk-записи, лимиты соединений на serverless).

## Roblox

- **roblox-dev** — проверенные знания по Roblox/Luau: скрипты и модули, RemoteEvents, DataStore и ProfileStore, ProcessReceipt и монетизация, UI, Input Action System, Parallel Luau, производительность, античит, устаревшие API, Rojo, MCP-инструменты Studio. Внутри — репозиторий с docs, evals, tests и install-скриптами.
- **roblox-physics** — физика и запросы: сборки, анкоринг, констрейнты, коллизионные группы, CanCollide/CanTouch/CanQuery, рейкасты и overlap-запросы, масса, импульсы, network ownership.
- **roblox-ui** — продакшн-интерфейсы: ScreenGui/PlayerGui, адаптивные UDim2, safe insets, переиспользуемые инстансы, ввод на всех устройствах, gamepad-фокус, ScrollingFrame, AutomaticSize.

## Инструменты, Cursor, инфраструктура

- **create-skill** — создание нового скилла и структура SKILL.md.
- **create-rule** — постоянные правила для ИИ: `.cursor/rules/`, RULE.md, AGENTS.md.
- **create-hook** — хуки Cursor: hooks.json и скрипты на события агента.
- **create-subagent** — свои типы субагентов: ревьюеры, дебаггеры, доменные ассистенты.
- **hookify-rules** — правила-«хуки» в Markdown с YAML: warn/block по regex на bash, файлы, промпты, стоп-события.
- **migrate-to-skills** — конвертация правил `.cursor/rules/*.mdc` и команд в формат Agent Skills.
- **configure-ecc** — мастер настройки ECC: инвентаризация, scope, режим хуков, предпросмотр, применение, проверка.
- **ecc-guide** — ответы про ECC по живому репозиторию: агенты, скиллы, команды, хуки, профили установки.
- **ecc-recipes** — карта «задача → группа команд ECC» с порядком запуска и условием остановки.
- **statusline** — кастомная строка статуса в CLI.
- **update-cli-config** — правка настроек Cursor CLI в `~/.cursor/cli-config.json`.
- **update-cursor-settings** — правка `settings.json` Cursor/VSCode: темы, шрифты, форматирование, автосохранение, кейбинды.
- **origin** — установка, вход, обновление и починка origin CLI для репозиториев на Cursor.
- **new-repo** — создание репозитория на Cursor и пуш проекта.
- **share** — сохранить/забэкапить/поделиться проектом на Cursor (приватный репозиторий, без знания git).
- **sdk** — Cursor SDK (`@cursor/sdk`, `cursor-sdk`): запуск агентов из скриптов, CI/CD, бэкенда; local vs cloud, MCP, стриминг, ошибки.
- **automate** — создание Cursor Automations.
- **onboard** — короткий онбординг: выяснить предпочтения, выбрать первую цель, направить к следующему шагу.
- **rename-chat** — переименовать текущий чат по его теме.
- **shell** — выполнить остаток запроса как буквальную shell-команду.
- **loop** — запуск промпта/скилла по интервалу в текущей сессии.
- **loop-design-check** — проектирование и проверка агентского цикла на типовые поломки: зацикливание, подгонка под проверку, «уверенно неверный» результат.
- **deploy-with-vercel** — привязка репозитория к Vercel и деплой через Vercel MCP.

---

## Полезные пометки

- **Зависимости:** `motion-advanced` и `motion-patterns` опираются на `motion-foundations`; `council-multi-model` — на `council`; `review` — обёртка над `review-bugbot` и `review-security`.
- **Устаревшее:** `continuous-learning` помечен deprecated, вместо него `continuous-learning-v2`.
- **Репозиторий внутри скилла:** `roblox-dev` содержит `.git`, `docs`, `evals`, `tests`, `tools`, `install.*`, `CHANGELOG.md` — при переносе копируется целиком.
- **Не входят в архив** (встроенные в OpenCode): `browser`, `opencode`, `report` — они поставляются вместе с приложением.
- **Размер и состав:** 158 папок, 423 файла, в основном `.md` (243), плюс Python-скрипты (45), XSD-схемы (39), shell-скрипты (19), TypeScript (15).
